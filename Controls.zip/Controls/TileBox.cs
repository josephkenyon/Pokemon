﻿using System.Drawing;
using System.Windows.Forms;

namespace LevelDesigner.Controls
{
    public abstract class TileBox : PictureBox
    {
        public Microsoft.Xna.Framework.Point SpriteLocation { get; private set; }

        public abstract void Setup(Microsoft.Xna.Framework.Point spriteLocation);

        protected static Image CropImage(Bitmap img, Point spriteLocation)
        {
            Bitmap bmpCrop = img.Clone(
                new Rectangle(0, 0, 0, 0),
                img.PixelFormat
            );
            return (bmpCrop);
        }
    }
}
