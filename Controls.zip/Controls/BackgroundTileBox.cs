﻿using System.Drawing;
using System.Windows.Forms;

namespace LevelDesigner.Controls
{
    public class BackgroundTileBox : PictureBox
    {
        public Microsoft.Xna.Framework.Point SpriteLocation { get; private set; }

        public void Setup(Microsoft.Xna.Framework.Point spriteLocation) { 
            
        }

        protected static Image CropImage(Image img, Rectangle cropArea)
        {
            Bitmap bmpImage = new Bitmap(img);
            Bitmap bmpCrop = bmpImage.Clone(cropArea,
            bmpImage.PixelFormat);
            return (Image)(bmpCrop);
        }
    }
}
