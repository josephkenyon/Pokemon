﻿using Microsoft.Xna.Framework.Graphics;
using MonoGame.Forms.Services;
using System.Drawing;
using System.IO;

namespace LevelDesigner
{
    public class ContentManager
    {
        public static Texture2D BackgroundtileSet { get; set; }
        public static Texture2D ForegroundtileSet { get; set; }
        public static Bitmap BackgroundtileSetBitmap { get; set; }
        public static Bitmap ForegroundtileSetBitmap { get; set; }

        public static void LoadContent(MonoGameService monoGameService) {
            BackgroundtileSet = monoGameService.Content.Load<Texture2D>("sprites\\tilesets\\backgroundTileset");
            ForegroundtileSet = monoGameService.Content.Load<Texture2D>("sprites\\tilesets\\foregroundTileset");

            Image img;
            using (MemoryStream MS = new MemoryStream())
            {
                BackgroundtileSet.SaveAsPng(MS, BackgroundtileSet.Width, BackgroundtileSet.Height);
                //Go To the  beginning of the stream.
                MS.Seek(0, SeekOrigin.Begin);
                //Create the image based on the stream.
                img = Image.FromStream(MS);
                ContentManager.BackgroundtileSetBitmap = new Bitmap(img);
            }

            img = null;
            using (MemoryStream MS = new MemoryStream())
            {
                ForegroundtileSet.SaveAsPng(MS, ForegroundtileSet.Width, ForegroundtileSet.Height);
                //Go To the  beginning of the stream.
                MS.Seek(0, SeekOrigin.Begin);
                //Create the image based on the stream.
                img = Image.FromStream(MS);
                ContentManager.ForegroundtileSetBitmap = new Bitmap(img);
            }
        }
    }
}
